
<html >
  <head>
<meta content="Hacked by 0N3R1D3R | Indonesia To World Team" name="subject">
<meta content="Hacked by 0N3R1D3R | Indonesia To World Team" name="Abstract">
<meta name="keywords" content="Hacked by 0N3R1D3R | Indonesia To World Team">
<meta content="Hacked by 0N3R1D3R | Indonesia To World Team" name="description">
<meta content="Hacked by 0N3R1D3R | Indonesia To World Team" name="copyright">
<meta content="Hacked by 0N3R1D3R | Indonesia To World Team" name="author">
<meta name="poptm" content="f499d91660571166f7c8dec23fcb6649" />
<link rel="shortcut icon" href="http://2.bp.blogspot.com/_OoNYJfsEuXI/TLGUge5UFdI/AAAAAAAAAY0/fCmNi6fnkp4/s400/indonesia.gif">
    <title>Indonesia To World Team</title>
	<script language="JavaScript">
var txt=" .:: ITW Team ::. ";
var kecepatan=100;var segarkan=null;function bergerak() { document.title=txt;
txt=txt.substring(1,txt.length)+txt.charAt(0);
segarkan=setTimeout("bergerak()",kecepatan);}bergerak();
    </script>
        <link rel="stylesheet" href="https://0n3r1d3r.000webhostapp.com/a.css">    
  </head>

<body oncontextmenu='return false;' onkeydown='return false;' onmousedown='return false;' ondragstart='return false' onselectstart='return false' style='-moz-user-select: none; cursor: default;'>
<center>
    <div class="wrapper">
	<div class="container">
	<font face="impact" style="font-size:40pt;">
	<style type="text/css">
	body {background-color:#000000;}
	#q {font: 30px impact;color:#FFD700;}
</style>
</script>
<script>alert("Hacked By 0N3R1D3R")</script>
<SCRIPT>
farbbibliothek = new Array(); 
farbbibliothek[0] = new Array("#FF0000","#FF1100","#FF2200","#FF3300","#FF4400","#FF5500","#FF6600","#FF7700","#FF8800","#FF9900","#FFaa00","#FFbb00","#FFcc00","#FFdd00","#FFee00","#FFff00","#FFee00","#FFdd00","#FFcc00","#FFbb00","#FFaa00","#FF9900","#FF8800","#FF7700","#FF6600","#FF5500","#FF4400","#FF3300","#FF2200","#FF1100"); 
farbbibliothek[1] = new Array("#FF0000","#FFFFFF","#FFFFFF","#FF0000"); 
farbbibliothek[2] = new Array("#FFFFFF","#FF0000","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"); 
farbbibliothek[3] = new Array("#FF0000","#FF4000","#FF8000","#FFC000","#FFFF00","#C0FF00","#80FF00","#40FF00","#00FF00","#00FF40","#00FF80","#00FFC0","#00FFFF","#00C0FF","#0080FF","#0040FF","#0000FF","#4000FF","#8000FF","#C000FF","#FF00FF","#FF00C0","#FF0080","#FF0040"); 
farbbibliothek[4] = new Array("#FF0000","#EE0000","#DD0000","#CC0000","#BB0000","#AA0000","#990000","#880000","#770000","#660000","#550000","#440000","#330000","#220000","#110000","#000000","#110000","#220000","#330000","#440000","#550000","#660000","#770000","#880000","#990000","#AA0000","#BB0000","#CC0000","#DD0000","#EE0000"); 
farbbibliothek[5] = new Array("#FF0000","#FF0000","#FF0000","#FFFFFF","#FFFFFF","#FFFFFF"); 
farbbibliothek[6] = new Array("#FF0000","#FDF5E6"); 
farbbibliothek[7] = new Array("red","gold"); 
farben = farbbibliothek[4];
function farbschrift() 
{ 
for(var i=0 ; i<Buchstabe.length; i++) 
{ 
document.all["a"+i].style.color=farben[i]; 
} 
farbverlauf(); 
} 
function string2array(text) 
{ 
Buchstabe = new Array(); 
while(farben.length<text.length) 
{ 
farben = farben.concat(farben); 
} 
k=0; 
while(k<=text.length) 
{ 
Buchstabe[k] = text.charAt(k); 
k++; 
} 
} 
function divserzeugen() 
{ 
for(var i=0 ; i<Buchstabe.length; i++) 
{ 
document.write("<span id='a"+i+"' class='a"+i+"'>"+Buchstabe[i] + "</span>"); 
} 
farbschrift(); 
} 
var a=1; 
function farbverlauf() 
{ 
for(var i=0 ; i<farben.length; i++) 
{ 
farben[i-1]=farben[i]; 
} 
farben[farben.length-1]=farben[-1]; 
setTimeout("farbschrift()",30); 
} 
// 
var farbsatz=1; 
function farbtauscher() 
{ 
farben = farbbibliothek[farbsatz]; 
while(farben.length<text.length) 
{ 
farben = farben.concat(farben); 
} 
farbsatz=Math.floor(Math.random()*(farbbibliothek.length-0.0001)); 
} 
setInterval("farbtauscher()",10000); 
text ="Indonesia To World Team";//h 
string2array(text);
divserzeugen(); 
//document.write(text); 
</SCRIPT>
</font>
<br><br><img src="http://i.imgur.com/gVatHQQ.png" height="300" width="300"/><br><br>
<marquee behavior="scroll" direction="left" scrollamount="100" scrolldelay="40" width="100%">
<font color="red">___________________________________________________________</font></marquee>
<div style="text-shadow: 0px 0px 5px red;"><span style="color: red;"><font face="transformers"><b>ALL TEAM : </b><marquee scrollamount="10" direction="left" width="50%"><span style="color: red;">.::<span style="color: white;"> <b>0N3R1D3R </b><span style="color: red;">| <span style="color: red;"><b>./MR.P0ME404 | EBULOBO | XS4BL9 | CYB3RH00D | ./N30F0RC3 | ./Mar ::.</b></marquee></font></div><script type="text/javascript">/*<![CDATA[*/new TypingText(document.getElementById("message"), 90, function(i){ var ar= new Array("_", " ", "_", " "); return "" +ar[i.length % ar.length]; });//Type out examples:TypingText.runAll();/*]]>*/</script>
<marquee behavior="scroll" direction="right" scrollamount="100" scrolldelay="40" width="100%">
<font color="red">___________________________________________________________</font></marquee> 
<br />
<embed src="https://www.youtube.com/v/T4qbm1pE6TQ&autoplay=1" type="application/x-shockwave-flash"wmode="transparent" width="1" height="1"></embed>
	</div>
	
	<ul class="bg-bubbles">
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
	</ul>
</div>
  </body>
</html>
